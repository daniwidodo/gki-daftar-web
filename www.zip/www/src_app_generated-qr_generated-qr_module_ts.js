(self["webpackChunkgki_daftar_web"] = self["webpackChunkgki_daftar_web"] || []).push([["src_app_generated-qr_generated-qr_module_ts"],{

/***/ 73064:
/*!*************************************************************!*\
  !*** ./src/app/generated-qr/generated-qr-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GeneratedQrPageRoutingModule": () => (/* binding */ GeneratedQrPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _generated_qr_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./generated-qr.page */ 38964);




const routes = [
    {
        path: '',
        component: _generated_qr_page__WEBPACK_IMPORTED_MODULE_0__.GeneratedQrPage
    }
];
let GeneratedQrPageRoutingModule = class GeneratedQrPageRoutingModule {
};
GeneratedQrPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], GeneratedQrPageRoutingModule);



/***/ }),

/***/ 62681:
/*!*****************************************************!*\
  !*** ./src/app/generated-qr/generated-qr.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GeneratedQrPageModule": () => (/* binding */ GeneratedQrPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _generated_qr_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./generated-qr-routing.module */ 73064);
/* harmony import */ var _generated_qr_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./generated-qr.page */ 38964);
/* harmony import */ var _techiediaries_ngx_qrcode__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @techiediaries/ngx-qrcode */ 89156);
/* harmony import */ var ngx_print__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ngx-print */ 95913);









let GeneratedQrPageModule = class GeneratedQrPageModule {
};
GeneratedQrPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            ngx_print__WEBPACK_IMPORTED_MODULE_4__.NgxPrintModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _generated_qr_routing_module__WEBPACK_IMPORTED_MODULE_0__.GeneratedQrPageRoutingModule,
            _techiediaries_ngx_qrcode__WEBPACK_IMPORTED_MODULE_8__.NgxQRCodeModule
        ],
        declarations: [_generated_qr_page__WEBPACK_IMPORTED_MODULE_1__.GeneratedQrPage]
    })
], GeneratedQrPageModule);



/***/ }),

/***/ 38964:
/*!***************************************************!*\
  !*** ./src/app/generated-qr/generated-qr.page.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GeneratedQrPage": () => (/* binding */ GeneratedQrPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_generated_qr_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./generated-qr.page.html */ 17451);
/* harmony import */ var _generated_qr_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./generated-qr.page.scss */ 21141);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _techiediaries_ngx_qrcode__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @techiediaries/ngx-qrcode */ 89156);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common/http */ 91841);
/* harmony import */ var _services_server_strapi_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/server-strapi.service */ 82607);
/* harmony import */ var _ionic_native_printer_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/printer/ngx */ 17008);









let GeneratedQrPage = class GeneratedQrPage {
    constructor(activatedroute, router, http, server, printer) {
        this.activatedroute = activatedroute;
        this.router = router;
        this.http = http;
        this.server = server;
        this.printer = printer;
        // https://stackoverflow.com/questions/52145130/how-to-build-browser-version-in-ionic-4
        // This works for me: ionic build --prod --public-url=/app/
        // https://forum.ionicframework.com/t/how-to-build-index-html-with-custom-title-and-base-href/189369
        this.name = 'Angular PDF';
        this.baseUrl = window.location.href;
        this.elementType = _techiediaries_ngx_qrcode__WEBPACK_IMPORTED_MODULE_4__.NgxQrcodeElementTypes.URL;
        this.correctionLevel = _techiediaries_ngx_qrcode__WEBPACK_IMPORTED_MODULE_4__.NgxQrcodeErrorCorrectionLevels.HIGH;
        this.endPoint = 'http://gkisulsel.org/regibadah';
        ////
        this.activatedroute.paramMap.subscribe((params) => {
            this.nikId = params.get('nikId');
            this.ibadahId = params.get('ibadahId');
            console.log('nik ID :', this.nikId);
            console.log('ibadah ID :', this.ibadahId);
        });
        ////
    }
    // https://www.c-sharpcorner.com/article/how-to-export-pdf-in-angular/
    ngOnInit() {
        const verifPage = this.endPoint + '/verif-page/' + this.nikId + '/' + this.ibadahId;
        this.value = verifPage;
        console.log(this.value);
    }
};
GeneratedQrPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.ActivatedRoute },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_6__.HttpClient },
    { type: _services_server_strapi_service__WEBPACK_IMPORTED_MODULE_2__.ServerStrapiService },
    { type: _ionic_native_printer_ngx__WEBPACK_IMPORTED_MODULE_3__.Printer }
];
GeneratedQrPage = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-generated-qr',
        template: _raw_loader_generated_qr_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_generated_qr_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], GeneratedQrPage);



/***/ }),

/***/ 21141:
/*!*****************************************************!*\
  !*** ./src/app/generated-qr/generated-qr.page.scss ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("#barcode {\n  margin-top: 15px;\n  display: block;\n  padding-left: 5%;\n  margin-left: auto;\n  margin-right: auto;\n  width: 250px;\n}\n\ntextarea {\n  margin-top: 15px;\n  display: block;\n  margin-left: auto;\n  margin-right: auto;\n  width: 250px;\n  opacity: 0.5;\n}\n\n#notif {\n  display: block;\n  padding-left: 5%;\n  padding-right: 5%;\n}\n\n.button {\n  margin-left: auto;\n  margin-right: auto;\n  display: block;\n  width: 135px;\n  height: 35px;\n  margin-top: 2%;\n  background-color: blue;\n  color: white;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImdlbmVyYXRlZC1xci5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0FBQ0o7O0FBRUE7RUFDSSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7QUFDSjs7QUFFQTtFQUNJLGNBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0FBQ0o7O0FBRUE7RUFDSSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0VBQ0EsY0FBQTtFQUNBLHNCQUFBO0VBQ0EsWUFBQTtBQUNKIiwiZmlsZSI6ImdlbmVyYXRlZC1xci5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIjYmFyY29kZSB7XHJcbiAgICBtYXJnaW4tdG9wOiAxNXB4O1xyXG4gICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDUlO1xyXG4gICAgbWFyZ2luLWxlZnQ6IGF1dG87XHJcbiAgICBtYXJnaW4tcmlnaHQ6IGF1dG87XHJcbiAgICB3aWR0aDogMjUwcHg7XHJcbn1cclxuXHJcbnRleHRhcmVhIHtcclxuICAgIG1hcmdpbi10b3A6IDE1cHg7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIG1hcmdpbi1sZWZ0OiBhdXRvO1xyXG4gICAgbWFyZ2luLXJpZ2h0OiBhdXRvO1xyXG4gICAgd2lkdGg6IDI1MHB4O1xyXG4gICAgb3BhY2l0eTogLjU7XHJcbn1cclxuXHJcbiNub3RpZiB7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIHBhZGRpbmctbGVmdDogNSU7XHJcbiAgICBwYWRkaW5nLXJpZ2h0OiA1JTtcclxufVxyXG5cclxuLmJ1dHRvbiB7XHJcbiAgICBtYXJnaW4tbGVmdDogYXV0bztcclxuICAgIG1hcmdpbi1yaWdodDogYXV0bztcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgd2lkdGg6IDEzNXB4O1xyXG4gICAgaGVpZ2h0OiAzNXB4O1xyXG4gICAgbWFyZ2luLXRvcDogMiU7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiBibHVlO1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG59Il19 */");

/***/ }),

/***/ 17451:
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/generated-qr/generated-qr.page.html ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n    <ngx-qrcode id=\"barcode\" [elementType]=\"elementType\" [errorCorrectionLevel]=\"correctionLevel\" [value]=\"value\" cssClass=\"bshadow\"></ngx-qrcode>\n\n    <!-- <textarea [(ngModel)]=\"value\"></textarea> -->\n\n    <div id=\"notif\">\n        <button class=\"button\" printTitle=\"Cetak QR Ibadah\" printSectionId=\"barcode\" ngxPrint> Cetak </button>\n        <!-- <ion-button printTitle=\"Print Title\" printSectionId=\"barcode\" ngxPrint class=\" button \" color=\"primary \"> Save Picture </ion-button> -->\n        <ol>\n            <li>\n                <p>\n                    QR Code pendaftaran ini tidak menjamin keikutsertaan dalam Ibadah Onsite apabila ditemukan ketidaksesuaian terhadap Syarat dan Ketentuan pendaftaran pada saat verifikasi di tempat.\n                </p>\n            </li>\n            <li>\n                <p>\n                    Seluruh jemaat wajib menggunakan masker selama beribadah dan mematuhi protokol kesehatan yang ditetapkan (5M).\n                </p>\n            </li>\n        </ol>\n    </div>\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_generated-qr_generated-qr_module_ts.js.map