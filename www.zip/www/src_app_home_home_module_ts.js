(self["webpackChunkgki_daftar_web"] = self["webpackChunkgki_daftar_web"] || []).push([["src_app_home_home_module_ts"],{

/***/ 52003:
/*!*********************************************!*\
  !*** ./src/app/home/home-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePageRoutingModule": () => (/* binding */ HomePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.page */ 62267);




const routes = [
    {
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_0__.HomePage,
    }
];
let HomePageRoutingModule = class HomePageRoutingModule {
};
HomePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], HomePageRoutingModule);



/***/ }),

/***/ 3467:
/*!*************************************!*\
  !*** ./src/app/home/home.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePageModule": () => (/* binding */ HomePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.page */ 62267);
/* harmony import */ var _home_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home-routing.module */ 52003);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/button */ 51095);








let HomePageModule = class HomePageModule {
};
HomePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _home_routing_module__WEBPACK_IMPORTED_MODULE_1__.HomePageRoutingModule,
            _angular_material_button__WEBPACK_IMPORTED_MODULE_7__.MatButtonModule
        ],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_0__.HomePage]
    })
], HomePageModule);



/***/ }),

/***/ 62267:
/*!***********************************!*\
  !*** ./src/app/home/home.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePage": () => (/* binding */ HomePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_home_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./home.page.html */ 49764);
/* harmony import */ var _home_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home.page.scss */ 2610);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 39895);





let HomePage = class HomePage {
    constructor(router) {
        this.router = router;
        this.checkbox1 = false;
        this.checkbox2 = false;
    }
    klik() {
        return console.log('klik');
    }
    goToPernahDaftar() {
        this.router.navigate(['/pernah-daftar']);
    }
    goToBelumDaftar() {
        this.router.navigate(['/belum-daftar']);
    }
    checkbox1Click(e) {
        console.log('check 1:', e.detail.checked);
        if (e.detail.checked === true) {
            this.checkbox1 = true;
        }
        else if (e.detail.checked === false) {
            this.checkbox1 = false;
        }
        ;
    }
    checkbox2Click(e) {
        console.log('check 2:', e.detail.checked);
        if (e.detail.checked === true) {
            this.checkbox2 = true;
        }
        else if (e.detail.checked === false) {
            this.checkbox2 = false;
        }
        ;
    }
};
HomePage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
HomePage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-home',
        template: _raw_loader_home_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_home_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], HomePage);



/***/ }),

/***/ 2610:
/*!*************************************!*\
  !*** ./src/app/home/home.page.scss ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("#container {\n  position: absolute;\n  border-radius: 10px;\n  padding-left: 5%;\n  padding-right: 5%;\n  top: 5%;\n}\n#container #container h1 {\n  font-size: 32px;\n  line-height: 26px;\n}\n#container #container p {\n  font-size: 16px;\n  line-height: 22px;\n  color: #8c8c8c;\n  margin: 0;\n}\n#container #container a {\n  text-decoration: none;\n}\n#background {\n  color: #e2fdf7;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksa0JBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxPQUFBO0FBQ0o7QUFBSTtFQUNJLGVBQUE7RUFDQSxpQkFBQTtBQUVSO0FBQUk7RUFDSSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0VBQ0EsU0FBQTtBQUVSO0FBQUk7RUFDSSxxQkFBQTtBQUVSO0FBRUE7RUFDSSxjQUFBO0FBQ0oiLCJmaWxlIjoiaG9tZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIjY29udGFpbmVyIHtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgICBwYWRkaW5nLWxlZnQ6IDUlO1xuICAgIHBhZGRpbmctcmlnaHQ6IDUlO1xuICAgIHRvcDogNSU7XG4gICAgI2NvbnRhaW5lciBoMSB7XG4gICAgICAgIGZvbnQtc2l6ZTogMzJweDtcbiAgICAgICAgbGluZS1oZWlnaHQ6IDI2cHg7XG4gICAgfVxuICAgICNjb250YWluZXIgcCB7XG4gICAgICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICAgICAgbGluZS1oZWlnaHQ6IDIycHg7XG4gICAgICAgIGNvbG9yOiAjOGM4YzhjO1xuICAgICAgICBtYXJnaW46IDA7XG4gICAgfVxuICAgICNjb250YWluZXIgYSB7XG4gICAgICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcbiAgICB9XG59XG5cbiNiYWNrZ3JvdW5kIHtcbiAgICBjb2xvcjogI2UyZmRmNztcbn0iXX0= */");

/***/ }),

/***/ 49764:
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content [fullscreen]=\"true\" id=\"background\">\n    <div id=\"container\">\n        <h1>Aplikasi Registrasi Ibadah</h1>\n        <!-- <h4>GKI SULSEL Jemaat Makassar</h4> -->\n\n\n        <!-- <ion-list>\n            <ion-item>\n\n                <ion-checkbox slot=\"start\"></ion-checkbox>\n                <ion-label>aaaa</ion-label>\n            </ion-item>\n        </ion-list> -->\n\n        <div>\n            <h4>SYARAT & KETENTUAN</h4>\n            <p>\n                Pastikan Anda membaca terlebih dahulu \"Syarat & Ketentuan\" dibawah ini dan harap mengisi data dengan benar dan jujur. (Data yang diinput akan dijaga kerahasiaannya)\n            </p>\n\n            <ol>\n                <li>Berusia diatas 12 tahun hingga 60 tahun.</li>\n                <li>\n                    Tidak melakukan kontak / interaksi fisik dengan orang yang terinfeksi COVID-19 dalam 2 (dua) minggu terakhir.\n                </li>\n                <li>\n                    Tidak berada dalam keadaan terinfeksi COVID-19 atau sedang menjalani isolasi mandiri.\n                </li>\n                <li>\n                    Dalam keadaan sehat dan tidak mengalami gejala berikut ini :\n                    <ul>\n                        <li>Demam (suhu badan diatas 37,5 °C)</li>\n                        <li>Sakit Kepala</li>\n                        <li>Sakit tenggorokan / batuk / pilek</li>\n                        <li>Kesulitan bernafas</li>\n                        <li>Kesulitan mencium bau / mengecap rasa</li>\n                        <li>\n                            Mual / Diare yang disertai salah satu atau beberapa gejala diatas\n                        </li>\n                    </ul>\n                </li>\n                <li>Sudah menerima vaksin minimal 1 (satu) kali.</li>\n                <li>1 registrasi maksimal untuk 1 orang</li>\n                <li>\n                    QR Code hanya dapat digunakan sekali, yakni sesuai tanggal registrasi dan tidak dapat dipindahtangankan / dititipkan.\n                </li>\n                <li>\n                    Seluruh jemaat wajib menggunakan Masker dan mematuhi protokol kesehatan yang ditetapkan (5M).\n                </li>\n            </ol>\n\n            <!-- <h1 *ngIf=\"checkbox1 === true && checkbox2 === true\">\n                <strong>wuhuu</strong>\n            </h1> -->\n\n            <!--  -->\n            <ion-list>\n                <ion-item>\n                    <ion-checkbox slot=\"start\" (ionChange)=\"checkbox1Click($event)\"></ion-checkbox>\n                    <p>Saya menyetujui dan memenuhi seluruh Syarat dan Ketentuan diatas.</p>\n                </ion-item>\n                <ion-item>\n                    <ion-checkbox slot=\"start\" (ionChange)=\"checkbox2Click($event)\"></ion-checkbox>\n                    <p>Saya memahami bahwa pendaftaran ini tidak menjamin keikutsertaan dalam Ibadah Onsite apabila ditemukan ketidaksesuaian terhadap Syarat dan Ketentuan diatas pada saat verifikasi di tempat.</p>\n                </ion-item>\n            </ion-list>\n\n            <div id=\"navigate-button\" *ngIf=\"checkbox1 === false || checkbox2 === false\">\n                <ion-button color=\"light\">\n                    Pernah Daftar\n                </ion-button>\n                <ion-button color=\"light\">\n                    Belum Pernah Daftar\n                </ion-button>\n            </div>\n\n\n\n\n\n            <div id=\"navigate-button\" *ngIf=\"checkbox1 === true && checkbox2 === true\">\n                <ion-button color=\"primary\" (click)=\"goToPernahDaftar()\">\n                    Pernah Daftar\n                </ion-button>\n                <ion-button color=\"primary\" (click)=\"goToBelumDaftar()\">\n                    Belum Pernah Daftar\n                </ion-button>\n            </div>\n\n\n        </div>\n    </div>\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_home_home_module_ts.js.map