(self["webpackChunkgki_daftar_web"] = self["webpackChunkgki_daftar_web"] || []).push([["src_app_daftar-ibadah-qr_daftar-ibadah-qr_module_ts"],{

/***/ 36060:
/*!*********************************************************************!*\
  !*** ./src/app/daftar-ibadah-qr/daftar-ibadah-qr-routing.module.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DaftarIbadahQrPageRoutingModule": () => (/* binding */ DaftarIbadahQrPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _daftar_ibadah_qr_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./daftar-ibadah-qr.page */ 74526);




const routes = [
    {
        path: '',
        component: _daftar_ibadah_qr_page__WEBPACK_IMPORTED_MODULE_0__.DaftarIbadahQrPage
    }
];
let DaftarIbadahQrPageRoutingModule = class DaftarIbadahQrPageRoutingModule {
};
DaftarIbadahQrPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], DaftarIbadahQrPageRoutingModule);



/***/ }),

/***/ 4099:
/*!*************************************************************!*\
  !*** ./src/app/daftar-ibadah-qr/daftar-ibadah-qr.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DaftarIbadahQrPageModule": () => (/* binding */ DaftarIbadahQrPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _daftar_ibadah_qr_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./daftar-ibadah-qr-routing.module */ 36060);
/* harmony import */ var _daftar_ibadah_qr_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./daftar-ibadah-qr.page */ 74526);







let DaftarIbadahQrPageModule = class DaftarIbadahQrPageModule {
};
DaftarIbadahQrPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _daftar_ibadah_qr_routing_module__WEBPACK_IMPORTED_MODULE_0__.DaftarIbadahQrPageRoutingModule
        ],
        declarations: [_daftar_ibadah_qr_page__WEBPACK_IMPORTED_MODULE_1__.DaftarIbadahQrPage]
    })
], DaftarIbadahQrPageModule);



/***/ }),

/***/ 74526:
/*!***********************************************************!*\
  !*** ./src/app/daftar-ibadah-qr/daftar-ibadah-qr.page.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DaftarIbadahQrPage": () => (/* binding */ DaftarIbadahQrPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_daftar_ibadah_qr_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./daftar-ibadah-qr.page.html */ 35056);
/* harmony import */ var _daftar_ibadah_qr_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./daftar-ibadah-qr.page.scss */ 18868);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _services_server_strapi_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/server-strapi.service */ 82607);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 91841);







let DaftarIbadahQrPage = class DaftarIbadahQrPage {
    constructor(server, activatedroute, httpClient, router) {
        this.server = server;
        this.activatedroute = activatedroute;
        this.httpClient = httpClient;
        this.router = router;
        this.kuotaHabis = false;
        this.sudahTerdaftar = false;
        this.belumTerdaftar = false;
        this.checkEventsMap = [];
    }
    ngOnInit() {
        this.activatedroute.paramMap.subscribe((params) => {
            this.userID = params.get('id');
            //console.log(this.userId);
        });
        this.getUser();
        this.getIbadahFromServer();
        //  if (this.sudahIbadah === true){
        //     console.log('sudah ibadah');
        //     // this.router.navigate(['/daftar-ibadah-qr']);
        //   }
        this.getEvents();
    }
    getIbadahFromServer() {
        console.log('<----------------->');
        this.httpClient
            .get(this.server.endpoint + '/api/ibadahs')
            .subscribe((response) => {
            const ibadahs = response;
            console.log(ibadahs);
            this.dataIbadahs = ibadahs.data;
            console.log(this.dataIbadahs);
            const quota = this.dataIbadahs.quota;
            this.ibadahId = this.dataIbadahs.id;
            this.namaIbadah = this.dataIbadahs.namaIbadah;
            this.jamIbadah = this.dataIbadahs.jam;
            ////
            const jumlahRelasiDataJemaat = this.dataIbadahs.jemaat.length;
            console.log('lenght jemaat :', jumlahRelasiDataJemaat);
            ////
            this.sisaQuota = quota - jumlahRelasiDataJemaat;
            console.log('sisa quota :', this.sisaQuota);
            ///
            if (this.totalSisaQuota <= 0) {
                this.kuotaHabis = true;
            }
            else {
                this.kuotaHabis = false;
            }
            this.arrayDataJemaats = this.dataIbadahs.jemaat;
            this.sudahIbadah = this.arrayDataJemaats
                .map((x) => x.id)
                .includes(this.getCurrentUserID);
            console.log('sudah ibadah: ', this.sudahIbadah);
            if (this.sudahIbadah === true) {
                this.sudahTerdaftar = true;
            }
            if (this.sudahIbadah === false) {
                this.belumTerdaftar = true;
            }
            console.log('sudah terdaftar', this.sudahTerdaftar);
        });
    }
    getUser() {
        this.httpClient
            .get(this.server.endpoint + '/api/jemaats/' + this.userID)
            .subscribe((response) => {
            this.userData = response;
            ////
            this.namaLengkap = this.userData.data.namaLengkap;
            this.nikId = this.userData.data.nik;
            this.getCurrentUserID = this.userData.data.id;
            ////
            console.log('data lengkap user:', this.userData);
            console.log('nama lengkap :', this.namaLengkap);
            console.log('data user id:', this.getCurrentUserID);
            // console.log('data sudah pilih ibadah:', this.sudahPilihIbadah);
        }, (error) => {
            console.log(error);
        }, () => { });
    }
    checkUserSudahPilihIbadah() {
        //this.httpClient.get()
    }
    generateQrToNextPage(ibadahId) {
        console.log(this.userID, ibadahId);
        this.httpClient
            .put(this.server.endpoint + '/api/jemaats/' + this.userID, {
            // eslint-disable-next-line @typescript-eslint/naming-convention
            ibadah_id: ibadahId,
        })
            .subscribe((response) => {
            console.log(response);
            this.router.navigate(['/generated-qr', this.userID, ibadahId]);
        });
    }
    getEvents() {
        this.httpClient
            .get(this.server.endpoint + '/api/events')
            .subscribe((res) => {
            this.responseEvents = res.data;
            // quota
            this.quotaEvent = this.responseEvents.map(x => x.quota);
            const totalRelasiEvent = this.responseEvents.map(x => x.jemaats.length);
            // eslint-disable-next-line @typescript-eslint/no-unused-expressions
            this.totalRelasiX = this.quotaEvent.map(function (v, i) {
                return v - totalRelasiEvent[i];
            });
            console.log(this.quotaEvent);
            console.log(this.totalRelasiX);
            // eslint-disable-next-line @typescript-eslint/no-shadow
            // const mapEvent = this.responseEvents.map((x) => x.jemaats);
            // const forEvent = mapEvent.forEach((x) =>
            //   // eslint-disable-next-line @typescript-eslint/no-shadow
            //   x.map((x) => x.id).includes(this.getCurrentUserID)
            // );
        });
    }
    updateEvents() { }
    generateQRevents(eventClickId, currentUserId) {
        currentUserId = this.userID;
        this.httpClient
            .put(this.server.endpoint + '/api/events/' + eventClickId, {
            // eslint-disable-next-line @typescript-eslint/naming-convention
            currentUserId,
        })
            .subscribe((response) => {
            console.log(response);
            this.router.navigate([
                '/generated-qr-events',
                this.userID,
                eventClickId,
            ]);
        });
        console.log(eventClickId, currentUserId);
    }
};
DaftarIbadahQrPage.ctorParameters = () => [
    { type: _services_server_strapi_service__WEBPACK_IMPORTED_MODULE_2__.ServerStrapiService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.ActivatedRoute },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpClient },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router }
];
DaftarIbadahQrPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-daftar-ibadah-qr',
        template: _raw_loader_daftar_ibadah_qr_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_daftar_ibadah_qr_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], DaftarIbadahQrPage);



/***/ }),

/***/ 18868:
/*!*************************************************************!*\
  !*** ./src/app/daftar-ibadah-qr/daftar-ibadah-qr.page.scss ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("#container {\n  padding-left: 5%;\n  padding-right: 5%;\n  top: 20%;\n  position: absolute;\n}\n\n#back-button {\n  padding-left: 5%;\n  padding-right: 5%;\n  top: 3%;\n  position: absolute;\n}\n\n#ibadah-card {\n  border: #2196f3 solid 3px;\n  border-radius: 10px;\n  margin-bottom: 20px;\n  padding: 10px;\n  height: 40vh;\n  width: 90vw;\n}\n\n#event-card {\n  border: green solid 3px;\n  border-radius: 10px;\n  margin-bottom: 20px;\n  padding: 10px;\n  height: 40vh;\n  width: 90vw;\n}\n\n#input {\n  border-radius: 10px;\n  border: lightgrey solid 1px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRhZnRhci1pYmFkYWgtcXIucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLFFBQUE7RUFDQSxrQkFBQTtBQUNKOztBQUVBO0VBQ0ksZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLE9BQUE7RUFDQSxrQkFBQTtBQUNKOztBQUVBO0VBQ0kseUJBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0EsYUFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0FBQ0o7O0FBRUE7RUFDRSx1QkFBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSxhQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7QUFDRjs7QUFFQTtFQUNJLG1CQUFBO0VBQ0EsMkJBQUE7QUFDSiIsImZpbGUiOiJkYWZ0YXItaWJhZGFoLXFyLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIiNjb250YWluZXIge1xyXG4gICAgcGFkZGluZy1sZWZ0OiA1JTtcclxuICAgIHBhZGRpbmctcmlnaHQ6IDUlO1xyXG4gICAgdG9wOiAyMCU7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbn1cclxuXHJcbiNiYWNrLWJ1dHRvbiB7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDUlO1xyXG4gICAgcGFkZGluZy1yaWdodDogNSU7XHJcbiAgICB0b3A6IDMlO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG59XHJcblxyXG4jaWJhZGFoLWNhcmQge1xyXG4gICAgYm9yZGVyOiAjMjE5NmYzIHNvbGlkIDNweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAyMHB4O1xyXG4gICAgcGFkZGluZzogMTBweDtcclxuICAgIGhlaWdodDogNDB2aDtcclxuICAgIHdpZHRoOiA5MHZ3O1xyXG59XHJcblxyXG4jZXZlbnQtY2FyZCB7XHJcbiAgYm9yZGVyOiBncmVlbiBzb2xpZCAzcHg7XHJcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICBtYXJnaW4tYm90dG9tOiAyMHB4O1xyXG4gIHBhZGRpbmc6IDEwcHg7XHJcbiAgaGVpZ2h0OiA0MHZoO1xyXG4gIHdpZHRoOiA5MHZ3O1xyXG59XHJcblxyXG4jaW5wdXQge1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgIGJvcmRlcjogbGlnaHRncmV5IHNvbGlkIDFweDtcclxufVxyXG4iXX0= */");

/***/ }),

/***/ 35056:
/*!***************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/daftar-ibadah-qr/daftar-ibadah-qr.page.html ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\r\n  <div id=\"back-button\">\r\n    <ion-button fill=\"outline\" [routerLink]=\"['/pernah-daftar']\">\r\n      <ion-icon slot=\"start\" name=\"chevron-back-circle-outline\"></ion-icon>\r\n      kembali\r\n    </ion-button>\r\n  </div>\r\n  <div id=\"container\">\r\n    <h1>Selamat datang, {{namaLengkap}}</h1>\r\n\r\n    <h3>Silahkan pilih ibadah</h3>\r\n    <div id=\"ibadah-card\" (click)=\"generateQrToNextPage(ibadahId)\">\r\n      <!-- (click)=\"generateQrToNextPage(ibadah.id)\" *ngFor=\"let ibadah of dataIbadahs \" -->\r\n\r\n\r\n\r\n      <div>\r\n        <ion-label>\r\n          <h2>{{namaIbadah}}</h2>\r\n        </ion-label>\r\n        <h4>Pukul : {{jamIbadah}}</h4>\r\n        <p *ngIf=\"!kuotaHabis\">sisa kuota <strong>{{sisaQuota}}</strong></p>\r\n        <p *ngIf=\"kuotaHabis\">maaf kuota habis</p>\r\n        <!-- <h2 *ngIf=\"sudahTerdaftar \"> Sudah terdaftar </h2> -->\r\n        <!-- <h2 *ngIf=\"belumTerdaftar \"> Belum terdaftar </h2> -->\r\n      </div>\r\n    </div>\r\n\r\n    <div>\r\n      <div *ngFor=\" let name of responseEvents \" id=\"event-card\">\r\n        <ion-label>\r\n          <div (click)=\"generateQRevents(name.id, nikId)\">\r\n            <h2>{{name.title}}</h2>\r\n            <!-- <h4>Sisa quota : {{totalRelasiX}}</h4> -->\r\n            <h4>Pukul : {{name.description}}</h4>\r\n            <p>sisa quota event 1 : {{totalRelasiX[0]}}</p>\r\n            <p>sisa quota event 2 : {{totalRelasiX[1]}}</p>\r\n          </div>\r\n        </ion-label>\r\n\r\n        <!-- <h4>Pukul : {{jamIbadah}}</h4> -->\r\n        <!-- <p *ngIf='!kuotaHabis'>sisa kuota <strong>{{sisaQuota}}</strong></p> -->\r\n        <!-- <p *ngIf='kuotaHabis'>maaf kuota habis</p> -->\r\n        <!-- <h2 *ngIf=\"sudahTerdaftar \"> Sudah terdaftar </h2> -->\r\n        <!-- <h2 *ngIf=\"belumTerdaftar \"> Belum terdaftar </h2> -->\r\n      </div>\r\n\r\n\r\n    </div>\r\n\r\n  </div>\r\n</ion-content>\r\n");

/***/ })

}]);
//# sourceMappingURL=src_app_daftar-ibadah-qr_daftar-ibadah-qr_module_ts.js.map