(self["webpackChunkgki_daftar_web"] = self["webpackChunkgki_daftar_web"] || []).push([["src_app_verif-page_verif-page_module_ts"],{

/***/ 88077:
/*!*********************************************************!*\
  !*** ./src/app/verif-page/verif-page-routing.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VerifPagePageRoutingModule": () => (/* binding */ VerifPagePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _verif_page_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./verif-page.page */ 52686);




const routes = [
    {
        path: '',
        component: _verif_page_page__WEBPACK_IMPORTED_MODULE_0__.VerifPagePage
    }
];
let VerifPagePageRoutingModule = class VerifPagePageRoutingModule {
};
VerifPagePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], VerifPagePageRoutingModule);



/***/ }),

/***/ 82231:
/*!*************************************************!*\
  !*** ./src/app/verif-page/verif-page.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VerifPagePageModule": () => (/* binding */ VerifPagePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _verif_page_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./verif-page-routing.module */ 88077);
/* harmony import */ var _verif_page_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./verif-page.page */ 52686);







let VerifPagePageModule = class VerifPagePageModule {
};
VerifPagePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _verif_page_routing_module__WEBPACK_IMPORTED_MODULE_0__.VerifPagePageRoutingModule
        ],
        declarations: [_verif_page_page__WEBPACK_IMPORTED_MODULE_1__.VerifPagePage]
    })
], VerifPagePageModule);



/***/ }),

/***/ 52686:
/*!***********************************************!*\
  !*** ./src/app/verif-page/verif-page.page.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VerifPagePage": () => (/* binding */ VerifPagePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_verif_page_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./verif-page.page.html */ 13947);
/* harmony import */ var _verif_page_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./verif-page.page.scss */ 45081);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ 91841);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _services_server_strapi_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/server-strapi.service */ 82607);








let VerifPagePage = class VerifPagePage {
    constructor(activatedroute, http, server, loadingCtrl) {
        this.activatedroute = activatedroute;
        this.http = http;
        this.server = server;
        this.loadingCtrl = loadingCtrl;
        this.verified = false;
        this.activatedroute.paramMap.subscribe((params) => {
            this.nikId = params.get('nikId');
            this.ibadahId = params.get('ibadahId');
            console.log('nik ID :', this.nikId);
            console.log('ibadah ID :', this.ibadahId);
            //////////////////////////
            this.http
                .get(this.server.endpoint + '/api/ibadahs/')
                .subscribe((response) => (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
                this.dataIbadah = response;
                console.log('response :', response);
                this.dataJemaat = this.dataIbadah.data.jemaat;
                console.log('data jemaat :', this.dataJemaat);
                this.namaIbadah = this.dataIbadah.data.namaIbadah;
                ////
                const loading = yield this.loadingCtrl.create({
                    cssClass: 'my-custom-class',
                    message: 'Please wait...',
                    duration: 2000
                });
                yield loading.present();
                const { role, data } = yield loading.onDidDismiss();
                console.log('Loading dismissed!');
                //////
                this.dataJemaat.filter((x) => {
                    this.hasilFilter = this.nikId.includes(x.id);
                    console.log(this.hasilFilter);
                    if (this.hasilFilter === true) {
                        this.verified = true;
                    }
                });
                //////
                console.log(response);
                console.log(this.namaIbadah);
                console.log('data ibadah :', this.dataIbadah);
                console.log('data ibadah :', this.dataJemaat);
                console.log('verified :', this.verified);
                //////////////
            }));
        });
    }
    ngOnInit() {
        this.http.get(this.server.endpoint + '/api/jemaats/' + this.nikId)
            .subscribe((user) => {
            console.log(user);
            const userData = user;
            this.namaJemaat = userData.data.namaLengkap;
            console.log(userData);
        });
    }
};
VerifPagePage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.ActivatedRoute },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpClient },
    { type: _services_server_strapi_service__WEBPACK_IMPORTED_MODULE_2__.ServerStrapiService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.LoadingController }
];
VerifPagePage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-verif-page',
        template: _raw_loader_verif_page_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_verif_page_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], VerifPagePage);



/***/ }),

/***/ 45081:
/*!*************************************************!*\
  !*** ./src/app/verif-page/verif-page.page.scss ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ2ZXJpZi1wYWdlLnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ 13947:
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/verif-page/verif-page.page.html ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <div *ngIf=\"verified\" style=\"margin-left: 20%; margin-top: 20%;\">\n    <h1 style=\"color:lightgreen; \" >Selamat!</h1>\n    <h4>anda terverifikasi</h4>\n    <h2><strong>{{namaJemaat}}</strong></h2>\n    <h2>di <strong>{{namaIbadah}}</strong></h2>\n  </div>\n\n  <div *ngIf=\"!verified\" style=\"margin-left: 20%; margin-top: 20%;\">\n    <h1 style=\"color: red; \">Maaf</h1>\n    <h4>anda belum terverifikasi</h4>\n  </div>\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_verif-page_verif-page_module_ts.js.map