(self["webpackChunkgki_daftar_web"] = self["webpackChunkgki_daftar_web"] || []).push([["src_app_generated-qr-events_generated-qr-events_module_ts"],{

/***/ 31500:
/*!***************************************************************************!*\
  !*** ./src/app/generated-qr-events/generated-qr-events-routing.module.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GeneratedQrEventsPageRoutingModule": () => (/* binding */ GeneratedQrEventsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _generated_qr_events_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./generated-qr-events.page */ 52780);




const routes = [
    {
        path: '',
        component: _generated_qr_events_page__WEBPACK_IMPORTED_MODULE_0__.GeneratedQrEventsPage
    }
];
let GeneratedQrEventsPageRoutingModule = class GeneratedQrEventsPageRoutingModule {
};
GeneratedQrEventsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], GeneratedQrEventsPageRoutingModule);



/***/ }),

/***/ 12674:
/*!*******************************************************************!*\
  !*** ./src/app/generated-qr-events/generated-qr-events.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GeneratedQrEventsPageModule": () => (/* binding */ GeneratedQrEventsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _generated_qr_events_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./generated-qr-events-routing.module */ 31500);
/* harmony import */ var _generated_qr_events_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./generated-qr-events.page */ 52780);
/* harmony import */ var _techiediaries_ngx_qrcode__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @techiediaries/ngx-qrcode */ 89156);








let GeneratedQrEventsPageModule = class GeneratedQrEventsPageModule {
};
GeneratedQrEventsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _generated_qr_events_routing_module__WEBPACK_IMPORTED_MODULE_0__.GeneratedQrEventsPageRoutingModule,
            _techiediaries_ngx_qrcode__WEBPACK_IMPORTED_MODULE_7__.NgxQRCodeModule
        ],
        declarations: [_generated_qr_events_page__WEBPACK_IMPORTED_MODULE_1__.GeneratedQrEventsPage]
    })
], GeneratedQrEventsPageModule);



/***/ }),

/***/ 52780:
/*!*****************************************************************!*\
  !*** ./src/app/generated-qr-events/generated-qr-events.page.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GeneratedQrEventsPage": () => (/* binding */ GeneratedQrEventsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_generated_qr_events_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./generated-qr-events.page.html */ 91310);
/* harmony import */ var _generated_qr_events_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./generated-qr-events.page.scss */ 86031);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _techiediaries_ngx_qrcode__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @techiediaries/ngx-qrcode */ 89156);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common/http */ 91841);
/* harmony import */ var _services_server_strapi_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/server-strapi.service */ 82607);
/* harmony import */ var _ionic_native_printer_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/printer/ngx */ 17008);









let GeneratedQrEventsPage = class GeneratedQrEventsPage {
    constructor(activatedroute, router, http, server, printer) {
        this.activatedroute = activatedroute;
        this.router = router;
        this.http = http;
        this.server = server;
        this.printer = printer;
        this.name = 'Angular PDF';
        this.baseUrl = window.location.href;
        this.elementType = _techiediaries_ngx_qrcode__WEBPACK_IMPORTED_MODULE_4__.NgxQrcodeElementTypes.URL;
        this.correctionLevel = _techiediaries_ngx_qrcode__WEBPACK_IMPORTED_MODULE_4__.NgxQrcodeErrorCorrectionLevels.HIGH;
        this.endPoint = 'http://gkisulsel.org/regibadah';
        this.activatedroute.paramMap.subscribe((params) => {
            this.nikId = params.get('nikId');
            this.eventsId = params.get('eventsId');
            console.log('nik ID :', this.nikId);
            console.log('ibadah ID :', this.eventsId);
        });
    }
    ngOnInit() {
        const verifPage = this.endPoint + '/verif-events/' + this.nikId + '/' + this.eventsId;
        this.value = verifPage;
        console.log(this.value);
    }
};
GeneratedQrEventsPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.ActivatedRoute },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_6__.HttpClient },
    { type: _services_server_strapi_service__WEBPACK_IMPORTED_MODULE_2__.ServerStrapiService },
    { type: _ionic_native_printer_ngx__WEBPACK_IMPORTED_MODULE_3__.Printer }
];
GeneratedQrEventsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-generated-qr-events',
        template: _raw_loader_generated_qr_events_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_generated_qr_events_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], GeneratedQrEventsPage);



/***/ }),

/***/ 86031:
/*!*******************************************************************!*\
  !*** ./src/app/generated-qr-events/generated-qr-events.page.scss ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("#barcode {\n  margin-top: 15px;\n  display: block;\n  padding-left: 5%;\n  margin-left: auto;\n  margin-right: auto;\n  width: 250px;\n}\n\ntextarea {\n  margin-top: 15px;\n  display: block;\n  margin-left: auto;\n  margin-right: auto;\n  width: 250px;\n  opacity: 0.5;\n}\n\n#notif {\n  display: block;\n  padding-left: 5%;\n  padding-right: 5%;\n}\n\n.button {\n  margin-left: auto;\n  margin-right: auto;\n  display: block;\n  width: 135px;\n  height: 35px;\n  margin-top: 2%;\n  background-color: blue;\n  color: white;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImdlbmVyYXRlZC1xci1ldmVudHMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtBQUNGOztBQUVBO0VBQ0UsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0FBQ0Y7O0FBRUE7RUFDRSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtBQUNGOztBQUVBO0VBQ0UsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLGNBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtFQUNBLGNBQUE7RUFDQSxzQkFBQTtFQUNBLFlBQUE7QUFDRiIsImZpbGUiOiJnZW5lcmF0ZWQtcXItZXZlbnRzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIiNiYXJjb2RlIHtcclxuICBtYXJnaW4tdG9wOiAxNXB4O1xyXG4gIGRpc3BsYXk6IGJsb2NrO1xyXG4gIHBhZGRpbmctbGVmdDogNSU7XHJcbiAgbWFyZ2luLWxlZnQ6IGF1dG87XHJcbiAgbWFyZ2luLXJpZ2h0OiBhdXRvO1xyXG4gIHdpZHRoOiAyNTBweDtcclxufVxyXG5cclxudGV4dGFyZWEge1xyXG4gIG1hcmdpbi10b3A6IDE1cHg7XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgbWFyZ2luLWxlZnQ6IGF1dG87XHJcbiAgbWFyZ2luLXJpZ2h0OiBhdXRvO1xyXG4gIHdpZHRoOiAyNTBweDtcclxuICBvcGFjaXR5OiAuNTtcclxufVxyXG5cclxuI25vdGlmIHtcclxuICBkaXNwbGF5OiBibG9jaztcclxuICBwYWRkaW5nLWxlZnQ6IDUlO1xyXG4gIHBhZGRpbmctcmlnaHQ6IDUlO1xyXG59XHJcblxyXG4uYnV0dG9uIHtcclxuICBtYXJnaW4tbGVmdDogYXV0bztcclxuICBtYXJnaW4tcmlnaHQ6IGF1dG87XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgd2lkdGg6IDEzNXB4O1xyXG4gIGhlaWdodDogMzVweDtcclxuICBtYXJnaW4tdG9wOiAyJTtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiBibHVlO1xyXG4gIGNvbG9yOiB3aGl0ZTtcclxufVxyXG4iXX0= */");

/***/ }),

/***/ 91310:
/*!*********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/generated-qr-events/generated-qr-events.page.html ***!
  \*********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\r\n  <ngx-qrcode id=\"barcode\" [elementType]=\"elementType\" [errorCorrectionLevel]=\"correctionLevel\" [value]=\"value\" cssClass=\"bshadow\"></ngx-qrcode>\r\n\r\n  <!-- <textarea [(ngModel)]=\"value\"></textarea> -->\r\n\r\n  <div id=\"notif\">\r\n      <button class=\"button\" printTitle=\"Cetak QR Ibadah\" printSectionId=\"barcode\" ngxPrint> Cetak </button>\r\n      <!-- <ion-button printTitle=\"Print Title\" printSectionId=\"barcode\" ngxPrint class=\" button \" color=\"primary \"> Save Picture </ion-button> -->\r\n      <ol>\r\n          <li>\r\n              <p>\r\n                  QR Code pendaftaran ini tidak menjamin keikutsertaan dalam Ibadah Onsite apabila ditemukan ketidaksesuaian terhadap Syarat dan Ketentuan pendaftaran pada saat verifikasi di tempat.\r\n              </p>\r\n          </li>\r\n          <li>\r\n              <p>\r\n                  Seluruh jemaat wajib menggunakan masker selama beribadah dan mematuhi protokol kesehatan yang ditetapkan (5M).\r\n              </p>\r\n          </li>\r\n      </ol>\r\n  </div>\r\n</ion-content>\r\n");

/***/ })

}]);
//# sourceMappingURL=src_app_generated-qr-events_generated-qr-events_module_ts.js.map