(self["webpackChunkgki_daftar_web"] = self["webpackChunkgki_daftar_web"] || []).push([["src_app_pernah-daftar_pernah-daftar_module_ts"],{

/***/ 64614:
/*!***************************************************************!*\
  !*** ./src/app/pernah-daftar/pernah-daftar-routing.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PernahDaftarPageRoutingModule": () => (/* binding */ PernahDaftarPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _pernah_daftar_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pernah-daftar.page */ 11153);




const routes = [
    {
        path: '',
        component: _pernah_daftar_page__WEBPACK_IMPORTED_MODULE_0__.PernahDaftarPage
    }
];
let PernahDaftarPageRoutingModule = class PernahDaftarPageRoutingModule {
};
PernahDaftarPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], PernahDaftarPageRoutingModule);



/***/ }),

/***/ 15994:
/*!*******************************************************!*\
  !*** ./src/app/pernah-daftar/pernah-daftar.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PernahDaftarPageModule": () => (/* binding */ PernahDaftarPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _pernah_daftar_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pernah-daftar-routing.module */ 64614);
/* harmony import */ var _pernah_daftar_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pernah-daftar.page */ 11153);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/button */ 51095);









//
let PernahDaftarPageModule = class PernahDaftarPageModule {
};
PernahDaftarPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _pernah_daftar_routing_module__WEBPACK_IMPORTED_MODULE_0__.PernahDaftarPageRoutingModule,
            _angular_material_button__WEBPACK_IMPORTED_MODULE_7__.MatButtonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule
        ],
        declarations: [_pernah_daftar_page__WEBPACK_IMPORTED_MODULE_1__.PernahDaftarPage]
    })
], PernahDaftarPageModule);



/***/ }),

/***/ 11153:
/*!*****************************************************!*\
  !*** ./src/app/pernah-daftar/pernah-daftar.page.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PernahDaftarPage": () => (/* binding */ PernahDaftarPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_pernah_daftar_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./pernah-daftar.page.html */ 36139);
/* harmony import */ var _pernah_daftar_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pernah-daftar.page.scss */ 74693);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ 91841);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _services_server_strapi_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/server-strapi.service */ 82607);








let PernahDaftarPage = class PernahDaftarPage {
    constructor(router, server, formBuilder, httpClient) {
        this.router = router;
        this.server = server;
        this.formBuilder = formBuilder;
        this.httpClient = httpClient;
        this.showIcon = false;
    }
    ngOnInit() { }
    // authenticate(nik){
    //   this.router.navigate(['/daftar-ibadah-qr']);
    // }
    checkUser(event) {
        console.log('check user!:', this.checkUserToServer.value);
        // this.server.getSingleUser(this.checkUserToServer.value).subscribe( (response) => {
        //   console.log(response);
        // });
        const inputValue = event.target.value;
        console.log(inputValue);
        this.httpClient
            .get(this.server.endpoint + '/search' + `?nik=`)
            .subscribe((response) => {
            console.log(response);
        });
        console.log();
    }
    verifiedUser() {
        console.log('user terverifikasi!');
        this.router.navigate(['/daftar-ibadah-qr', this.userId[0].id]);
    }
    getInput(event) {
        console.log(event.target.value);
        this.httpClient
            .get(this.server.endpoint + '/api/search/' + event.target.value)
            .subscribe((response) => {
            this.nik = response;
            this.userId = response;
            console.log(response);
            console.log(this.userId);
            if (this.nik.length === 0) {
                return (this.showIcon = false);
            }
            else {
                return (this.showIcon = true);
            }
        });
    }
};
PernahDaftarPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router },
    { type: _services_server_strapi_service__WEBPACK_IMPORTED_MODULE_2__.ServerStrapiService },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpClient }
];
PernahDaftarPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-pernah-daftar',
        template: _raw_loader_pernah_daftar_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_pernah_daftar_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], PernahDaftarPage);



/***/ }),

/***/ 74693:
/*!*******************************************************!*\
  !*** ./src/app/pernah-daftar/pernah-daftar.page.scss ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("#input {\n  border: lightgray solid 1px;\n  border-radius: 5px;\n  margin-bottom: 16px;\n}\n\n#container {\n  padding-left: 5%;\n  padding-right: 5%;\n  top: 20%;\n  position: absolute;\n  width: 50%;\n}\n\n#back-button {\n  padding-left: 5%;\n  padding-right: 5%;\n  top: 3%;\n  position: absolute;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBlcm5haC1kYWZ0YXIucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksMkJBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0FBQ0o7O0FBRUE7RUFDSSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsUUFBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtBQUNKOztBQUVBO0VBQ0ksZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLE9BQUE7RUFDQSxrQkFBQTtBQUNKIiwiZmlsZSI6InBlcm5haC1kYWZ0YXIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiI2lucHV0IHtcclxuICAgIGJvcmRlcjogbGlnaHRncmF5IHNvbGlkIDFweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDVweDtcclxuICAgIG1hcmdpbi1ib3R0b206IDE2cHg7XHJcbn1cclxuXHJcbiNjb250YWluZXIge1xyXG4gICAgcGFkZGluZy1sZWZ0OiA1JTtcclxuICAgIHBhZGRpbmctcmlnaHQ6IDUlO1xyXG4gICAgdG9wOiAyMCU7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB3aWR0aDogNTAlO1xyXG59XHJcblxyXG4jYmFjay1idXR0b24ge1xyXG4gICAgcGFkZGluZy1sZWZ0OiA1JTtcclxuICAgIHBhZGRpbmctcmlnaHQ6IDUlO1xyXG4gICAgdG9wOiAzJTtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxufSJdfQ== */");

/***/ }),

/***/ 36139:
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pernah-daftar/pernah-daftar.page.html ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n    <div id=\"back-button\">\n        <ion-button fill=\"outline\" [routerLink]=\"['/home']\">\n            <ion-icon slot=\"start\" name=\"chevron-back-circle-outline\"></ion-icon>\n            kembali\n        </ion-button>\n    </div>\n\n    <div id=\"container\">\n        <div id=\"input\">\n            <!-- Input with placeholder -->\n            <!-- each input post request to server confirm nik -->\n\n            <ion-input placeholder=\"Masukkan NIK\" type=\"text\" (ionChange)='getInput($event)'>\n                <ion-icon name=\"alert-outline\" style=\"color: orange;\" slot=\"end\" *ngIf=\"showIcon === false\"></ion-icon>\n                <ion-icon name=\"checkmark-outline\" style=\"color: green;\" *ngIf=\"showIcon === true\"></ion-icon>\n            </ion-input>\n        </div>\n\n\n        <ion-button color=\"medium\" *ngIf=\"showIcon === false\"> Silahkan lengkapi data </ion-button>\n        <ion-button color=\"primary\" *ngIf=\"showIcon === true\" (click)=\"verifiedUser()\"> Lanjutkan </ion-button>\n    </div>\n\n\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_pernah-daftar_pernah-daftar_module_ts.js.map