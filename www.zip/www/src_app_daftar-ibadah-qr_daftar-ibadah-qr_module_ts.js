(self["webpackChunkgki_daftar_web"] = self["webpackChunkgki_daftar_web"] || []).push([["src_app_daftar-ibadah-qr_daftar-ibadah-qr_module_ts"],{

/***/ 36060:
/*!*********************************************************************!*\
  !*** ./src/app/daftar-ibadah-qr/daftar-ibadah-qr-routing.module.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DaftarIbadahQrPageRoutingModule": () => (/* binding */ DaftarIbadahQrPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _daftar_ibadah_qr_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./daftar-ibadah-qr.page */ 74526);




const routes = [
    {
        path: '',
        component: _daftar_ibadah_qr_page__WEBPACK_IMPORTED_MODULE_0__.DaftarIbadahQrPage
    }
];
let DaftarIbadahQrPageRoutingModule = class DaftarIbadahQrPageRoutingModule {
};
DaftarIbadahQrPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], DaftarIbadahQrPageRoutingModule);



/***/ }),

/***/ 4099:
/*!*************************************************************!*\
  !*** ./src/app/daftar-ibadah-qr/daftar-ibadah-qr.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DaftarIbadahQrPageModule": () => (/* binding */ DaftarIbadahQrPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _daftar_ibadah_qr_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./daftar-ibadah-qr-routing.module */ 36060);
/* harmony import */ var _daftar_ibadah_qr_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./daftar-ibadah-qr.page */ 74526);







let DaftarIbadahQrPageModule = class DaftarIbadahQrPageModule {
};
DaftarIbadahQrPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _daftar_ibadah_qr_routing_module__WEBPACK_IMPORTED_MODULE_0__.DaftarIbadahQrPageRoutingModule
        ],
        declarations: [_daftar_ibadah_qr_page__WEBPACK_IMPORTED_MODULE_1__.DaftarIbadahQrPage]
    })
], DaftarIbadahQrPageModule);



/***/ }),

/***/ 74526:
/*!***********************************************************!*\
  !*** ./src/app/daftar-ibadah-qr/daftar-ibadah-qr.page.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DaftarIbadahQrPage": () => (/* binding */ DaftarIbadahQrPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_daftar_ibadah_qr_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./daftar-ibadah-qr.page.html */ 35056);
/* harmony import */ var _daftar_ibadah_qr_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./daftar-ibadah-qr.page.scss */ 18868);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _services_server_strapi_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/server-strapi.service */ 82607);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 91841);







let DaftarIbadahQrPage = class DaftarIbadahQrPage {
    constructor(server, activatedroute, httpClient, router) {
        this.server = server;
        this.activatedroute = activatedroute;
        this.httpClient = httpClient;
        this.router = router;
        this.kuotaHabis = false;
    }
    ngOnInit() {
        this.activatedroute.paramMap.subscribe((params) => {
            this.userID = params.get('id');
            //console.log(this.userId);
        });
        this.getUser();
        this.getIbadahFromServer();
        //  if (this.sudahIbadah === true){
        //     console.log('sudah ibadah');
        //     // this.router.navigate(['/daftar-ibadah-qr']);
        //   }
    }
    getIbadahFromServer() {
        this.httpClient
            .get(this.server.endpoint + '/api/ibadahs')
            .subscribe((response) => {
            this.ibadahs = response;
            this.dataIbadahs = this.ibadahs.data;
            this.sisaQuota = this.ibadahs.data[0].quota;
            this.jumlahRelasiDataJemaat = this.ibadahs.data[0].jemaat.length;
            this.totalSisaQuota = this.sisaQuota - this.jumlahRelasiDataJemaat;
            ////
            // eslint-disable-next-line eqeqeq
            // if (this.sudahIbadah == true) {
            //   console.log('zzz');
            //   this.router.navigate(['/generated-qr', this.nikId, this.ibadahId]);
            // }
            console.log('<----------------->');
            console.log('response lengkap ibadah :', this.ibadahs);
            console.log('data ibadah :', this.dataIbadahs);
            console.log('quota', this.sisaQuota);
            console.log('sisaQuota :');
            // console.log('ibadah id :', this.ibadahId);
            // console.log('concat data jemaats :', this.allDataJemaats);
            // console.log('array data jemaats :', this.arrayDataJemaats);
            // console.log('jumlah relasi:', this.jumlahRelasiDataJemaat);
            console.log('<----------------->');
        });
    }
    getUser() {
        this.httpClient
            .get(this.server.endpoint + '/api/jemaats/' + this.userID)
            .subscribe((response) => {
            this.userData = response;
            ////
            this.namaLengkap = this.userData.data.namaLengkap;
            this.nikId = this.userData.data.nik;
            this.getCurrentUserID = this.userData.data.id;
            ////
            console.log('data lengkap user:', this.userData);
            console.log('nama lengkap :', this.namaLengkap);
            console.log('data user id:', this.getCurrentUserID);
            // console.log('data sudah pilih ibadah:', this.sudahPilihIbadah);
        }, (error) => {
            console.log(error);
        }, () => { });
    }
    checkUserSudahPilihIbadah() {
        //this.httpClient.get()
    }
    generateQrToNextPage(ibadahId) {
        console.log(this.userID, ibadahId);
        this.httpClient.put(this.server.endpoint + '/api/jemaats/' + this.userID, {
            // eslint-disable-next-line @typescript-eslint/naming-convention
            // eslint-disable-next-line @typescript-eslint/naming-convention
            ibadah_id: ibadahId,
        })
            .subscribe((response) => {
            console.log(response);
            this.router.navigate(['/generated-qr', this.userID, ibadahId]);
        });
        // const updateQuota: FormData = new FormData();
        // updateQuota.append('quota', this.sisaQuota);
        // this.httpClient
        //   .put(this.server.endpoint + '/ibadahs/' + ibadahId, {
        //     // eslint-disable-next-line @typescript-eslint/naming-convention
        //     data_jemaats: this.allDataJemaats,
        //   })
        //   .subscribe(
        //     (response) => {
        //       console.log(response);
        //       this.router.navigate(['/generated-qr', this.nikId, this.ibadahId]);
        //     },
        //     (error) => {
        //       console.log(error);
        //     },
        //     () => {}
        //   );
        // this.router.navigate(['/generated-qr', this.userId, ibadahId]);
    }
};
DaftarIbadahQrPage.ctorParameters = () => [
    { type: _services_server_strapi_service__WEBPACK_IMPORTED_MODULE_2__.ServerStrapiService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.ActivatedRoute },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpClient },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router }
];
DaftarIbadahQrPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-daftar-ibadah-qr',
        template: _raw_loader_daftar_ibadah_qr_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_daftar_ibadah_qr_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], DaftarIbadahQrPage);

// this.sisaQuota = response[0].quota - 1;
// this.ibadahId = response[0].id;
// this.allDataJemaats = response[0].data_jemaats.concat({
//   id: this.getCurrentUserID,
// });
// this.jumlahRelasiDataJemaat = response[0].data_jemaats.length;
// ////
// this.arrayDataJemaats = response[0].data_jemaats;
// this.sudahIbadah = this.arrayDataJemaats
//   .map((x) => x.id)
//   .includes(this.getCurrentUserID);
// console.log('sudah ibadah: ', this.sudahIbadah);
// ////
// ////
// this.totalSisaQuota = this.sisaQuota - this.jumlahRelasiDataJemaat;
// console.log('totalSisaQuota:', this.totalSisaQuota);
// if (this.totalSisaQuota <= 0) {
//   this.kuotaHabis = true;
// } else {
//   this.kuotaHabis = false;
// }


/***/ }),

/***/ 18868:
/*!*************************************************************!*\
  !*** ./src/app/daftar-ibadah-qr/daftar-ibadah-qr.page.scss ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("#container {\n  padding-left: 5%;\n  padding-right: 5%;\n  top: 20%;\n  position: absolute;\n}\n\n#back-button {\n  padding-left: 5%;\n  padding-right: 5%;\n  top: 3%;\n  position: absolute;\n}\n\n#ibadah-card {\n  border: lightseagreen solid 1px;\n  border-radius: 10px;\n  margin-bottom: 20px;\n  padding: 10px;\n  height: 180px;\n  width: 300px;\n}\n\n#input {\n  border-radius: 10px;\n  border: lightgrey solid 1px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRhZnRhci1pYmFkYWgtcXIucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLFFBQUE7RUFDQSxrQkFBQTtBQUNKOztBQUVBO0VBQ0ksZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLE9BQUE7RUFDQSxrQkFBQTtBQUNKOztBQUVBO0VBQ0ksK0JBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0EsYUFBQTtFQUNBLGFBQUE7RUFDQSxZQUFBO0FBQ0o7O0FBRUE7RUFDSSxtQkFBQTtFQUNBLDJCQUFBO0FBQ0oiLCJmaWxlIjoiZGFmdGFyLWliYWRhaC1xci5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIjY29udGFpbmVyIHtcclxuICAgIHBhZGRpbmctbGVmdDogNSU7XHJcbiAgICBwYWRkaW5nLXJpZ2h0OiA1JTtcclxuICAgIHRvcDogMjAlO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG59XHJcblxyXG4jYmFjay1idXR0b24ge1xyXG4gICAgcGFkZGluZy1sZWZ0OiA1JTtcclxuICAgIHBhZGRpbmctcmlnaHQ6IDUlO1xyXG4gICAgdG9wOiAzJTtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxufVxyXG5cclxuI2liYWRhaC1jYXJkIHtcclxuICAgIGJvcmRlcjogbGlnaHRzZWFncmVlbiBzb2xpZCAxcHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMjBweDtcclxuICAgIHBhZGRpbmc6IDEwcHg7XHJcbiAgICBoZWlnaHQ6IDE4MHB4O1xyXG4gICAgd2lkdGg6IDMwMHB4O1xyXG59XHJcblxyXG4jaW5wdXQge1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgIGJvcmRlcjogbGlnaHRncmV5IHNvbGlkIDFweDtcclxufSJdfQ== */");

/***/ }),

/***/ 35056:
/*!***************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/daftar-ibadah-qr/daftar-ibadah-qr.page.html ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n    <div id=\"back-button\">\n        <ion-button fill=\"outline\" [routerLink]=\"['/pernah-daftar']\">\n            <ion-icon slot=\"start\" name=\"chevron-back-circle-outline\"></ion-icon>\n            kembali\n        </ion-button>\n    </div>\n    <div id=\"container\">\n        <h1>Selamat datang, {{namaLengkap}}</h1>\n\n        <h3>Silahkan pilih ibadah </h3>\n        <div id=\"ibadah-card\" *ngFor=\"let ibadah of dataIbadahs \" style=\"background: blanchedalmond;\" (click)=\"generateQrToNextPage(ibadah.id)\">\n            <ion-label>\n                <h2>{{ibadah.namaIbadah}}</h2>\n            </ion-label>\n            <h4>Pukul : {{ibadah.jam}}</h4>\n            <p *ngIf='!kuotaHabis'>sisa kuota <strong>{{totalSisaQuota}}</strong></p>\n            <p *ngIf='kuotaHabis'>maaf kuota habis</p>\n        </div>\n\n\n    </div>\n\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_daftar-ibadah-qr_daftar-ibadah-qr_module_ts.js.map