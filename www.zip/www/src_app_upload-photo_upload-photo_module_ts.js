(self["webpackChunkgki_daftar_web"] = self["webpackChunkgki_daftar_web"] || []).push([["src_app_upload-photo_upload-photo_module_ts"],{

/***/ 9794:
/*!*************************************************************!*\
  !*** ./src/app/upload-photo/upload-photo-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UploadPhotoPageRoutingModule": () => (/* binding */ UploadPhotoPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _upload_photo_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./upload-photo.page */ 71216);




const routes = [
    {
        path: '',
        component: _upload_photo_page__WEBPACK_IMPORTED_MODULE_0__.UploadPhotoPage
    }
];
let UploadPhotoPageRoutingModule = class UploadPhotoPageRoutingModule {
};
UploadPhotoPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], UploadPhotoPageRoutingModule);



/***/ }),

/***/ 79112:
/*!*****************************************************!*\
  !*** ./src/app/upload-photo/upload-photo.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UploadPhotoPageModule": () => (/* binding */ UploadPhotoPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _upload_photo_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./upload-photo-routing.module */ 9794);
/* harmony import */ var _upload_photo_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./upload-photo.page */ 71216);








let UploadPhotoPageModule = class UploadPhotoPageModule {
};
UploadPhotoPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _upload_photo_routing_module__WEBPACK_IMPORTED_MODULE_0__.UploadPhotoPageRoutingModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule
        ],
        declarations: [_upload_photo_page__WEBPACK_IMPORTED_MODULE_1__.UploadPhotoPage]
    })
], UploadPhotoPageModule);



/***/ }),

/***/ 71216:
/*!***************************************************!*\
  !*** ./src/app/upload-photo/upload-photo.page.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UploadPhotoPage": () => (/* binding */ UploadPhotoPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_upload_photo_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./upload-photo.page.html */ 9704);
/* harmony import */ var _upload_photo_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./upload-photo.page.scss */ 25660);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ 91841);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 3679);






let UploadPhotoPage = class UploadPhotoPage {
    constructor(http, formBuilder) {
        this.http = http;
        this.formBuilder = formBuilder;
        this.userForm = this.formBuilder.group({
            namaLengkap: ['']
        });
    }
    ngOnInit() { }
    onFileChange(fileChangeEvent) {
        this.file = fileChangeEvent.target.files[0];
        console.log(this.file);
    }
    submitForm() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            const formData = new FormData();
            formData.append('photo', this.file, this.file.name);
            this.http
                .post('http://localhost:1337/data-jemaats', formData)
                .subscribe((response) => {
                console.log(response);
            });
        });
    }
    jsonForm() {
        const userData = JSON.stringify(this.userForm.value);
        console.log(userData);
    }
    cobaForm() {
        const formData = new FormData();
        console.log(this.file);
        const userData = JSON.stringify(this.userForm.value);
        console.log(this.userForm);
        formData.append('data', userData);
        formData.append('files.kartuVaksin', this.file, this.file.name);
        this.http
            .post('http://localhost:1337/data-jemaats', formData)
            .subscribe((response) => {
            console.log(response);
        });
    }
};
UploadPhotoPage.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpClient },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder }
];
UploadPhotoPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-upload-photo',
        template: _raw_loader_upload_photo_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_upload_photo_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], UploadPhotoPage);



/***/ }),

/***/ 25660:
/*!*****************************************************!*\
  !*** ./src/app/upload-photo/upload-photo.page.scss ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ1cGxvYWQtcGhvdG8ucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ 9704:
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/upload-photo/upload-photo.page.html ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n    <ion-toolbar>\n        <ion-title>uploadPhoto</ion-title>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <!-- <form [formGroup]=\"userForm\">\n        <input type=\"file\" (change)=\"onFileChange($event)\" formControlName=\"files.kartuVaksin\" />\n\n        <div formGroupName=\"data\">\n            <input type=\"text\" formControlName=\"namaLengkap\" />\n        </div>\n\n\n    </form> -->\n\n\n    <div [formGroup]=\"userForm\">\n        <input type=\"file\" (change)=\"onFileChange($event)\" />\n        <input type=\"text\" formControlName=\"namaLengkap\" />\n    </div>\n\n\n    <!-- <ion-button color=\"primary\" expand=\"full\" (click)=\"submitForm()\">Upload</ion-button> -->\n    <ion-button color=\"primary\" expand=\"full\" (click)=\"cobaForm()\">Upload</ion-button>\n    <ion-button color=\"primary\" expand=\"full\" (click)=\"jsonForm()\">json</ion-button>\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_upload-photo_upload-photo_module_ts.js.map